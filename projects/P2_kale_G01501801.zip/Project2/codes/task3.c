#include <stdio.h>
#include <openssl/bn.h>

int main() {
    BIGNUM *M = BN_new();
    BIGNUM *n = BN_new();
    BIGNUM *d = BN_new();
    BIGNUM *C = BN_new();
    BN_CTX *ctx = BN_CTX_new();

    // Convert the decimal strings to BIGNUM
    BN_hex2bn(&C, "0E5A8B792C606877C733273B76338267F2BE36FA5FF58AEA468511135204C9FA");
    BN_hex2bn(&d, "3587A24598E5F2A21DB007D89D18CC50ABA5075BA19A33890FE7C28A9B496AEB");
    BN_hex2bn(&n, "E103ABD94892E3E74AFD724BF28E78366D9676BCCC70118BD0AA1968DBB143D1");
    
    //calculate Plain Text M= C^d modn
    BN_mod_exp(M, C, d, n, ctx);


    // Output Plain Text in hexadecimal
    char *M_str = BN_bn2hex(M);
    printf("Plain Text: %s\n", M_str);

    // Free memory
    BN_free(M);
    BN_free(n);
    BN_free(d);
    BN_free(C);
    BN_CTX_free(ctx);
    OPENSSL_free(M_str);

    return 0;
}

