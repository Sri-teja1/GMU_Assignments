#include <stdio.h>
#include <openssl/bn.h>

int main() {
    BIGNUM *e = BN_new();
    BIGNUM *M = BN_new();
    BIGNUM *n = BN_new();
    BIGNUM *C = BN_new();
    BN_CTX *ctx = BN_CTX_new();

    // Convert the decimal strings to BIGNUM
    BN_hex2bn(&n, "E103ABD94892E3E74AFD724BF28E78366D9676BCCC70118BD0AA1968DBB143D1");
    BN_hex2bn(&e, "0D88C3");
    BN_hex2bn(&M, "4d696e692050726f6a656374203221");

    
    //calculate cipher text c= M^e modn
    BN_mod_exp(C, M, e, n, ctx);


    // Output Cipher text in hexadecimal
    char *C_str = BN_bn2hex(C);
    printf("Cipher Text: %s\n", C_str);

    // Free memory
    BN_free(e);
    BN_free(n);
    BN_free(M);
    BN_free(C);
    BN_CTX_free(ctx);
    OPENSSL_free(C_str);

    return 0;
}

