#include <stdio.h>
#include <openssl/bn.h>

int main() {
    BIGNUM *p = BN_new();
    BIGNUM *q = BN_new();
    BIGNUM *e = BN_new();
    BIGNUM *n = BN_new();
    BIGNUM *phi_n = BN_new();
    BIGNUM *p_minus_1 = BN_new();
    BIGNUM *q_minus_1 = BN_new();
    BIGNUM *one = BN_new();
    BIGNUM *d = BN_new();
    BN_CTX *ctx = BN_CTX_new();

    // Convert the decimal strings to BIGNUM
    BN_hex2bn(&p, "F7E75FDC469067FFDC4E847C51F452DF");
    BN_hex2bn(&q, "E85CED54AF57E53E092113E62F436F4F");
    BN_hex2bn(&e, "0D88C3");

    // Set 'one' to 1
    BN_set_word(one, 1);

    // Calculate p - 1
    BN_sub(p_minus_1, p, one);

    // Calculate q - 1
    BN_sub(q_minus_1, q, one);

    // Calculate phi_n = (p - 1) * (q - 1)
    BN_mul(phi_n, p_minus_1, q_minus_1, ctx);

    // Calculate n = p * q
    BN_mul(n, p, q, ctx);
    
    // Calculate private key d= inverse of e mod phi_n
    BN_mod_inverse(d, e, phi_n, ctx);

    //Output (d,n)
    char *n_str = BN_bn2hex(n);
    char *d_str = BN_bn2hex(d);
    printf("private key (d,n)= (%s,%s)\n", d_str, n_str);

    // Free memory
    BN_free(p);
    BN_free(q);
    BN_free(e);
    BN_free(n);
    BN_free(phi_n);
    BN_free(p_minus_1);
    BN_free(q_minus_1);
    BN_free(one);
    BN_free(d);
    BN_CTX_free(ctx);
    OPENSSL_free(n_str);
    OPENSSL_free(d_str);

    return 0;
}

