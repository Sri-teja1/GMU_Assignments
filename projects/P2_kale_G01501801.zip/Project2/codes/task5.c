#include <stdio.h>
#include <openssl/bn.h>

// Function to calculate M = S^e mod n and compare with Message
void verify_signature(BIGNUM *Message, BIGNUM *S, BIGNUM *e, BIGNUM *n, BN_CTX *ctx) {
    BIGNUM *M = BN_new();

    // Calculate M = S^e mod n
    BN_mod_exp(M, S, e, n, ctx);

    // Output the computed message
    char *M_str = BN_bn2hex(M);
    printf("Computed Message (M): %s\n", M_str);

    // Compare M with the original Message
    if (BN_cmp(M, Message) == 0) {
        printf("Message is sent by Alice\n");
    } else {
        printf("Message is not sent by Alice\n");
    }

    // Free memory
    BN_free(M);
    OPENSSL_free(M_str);
}

int main() {
    BIGNUM *Message = BN_new();
    BIGNUM *S = BN_new();
    BIGNUM *Modified_S = BN_new();
    BIGNUM *n = BN_new();
    BIGNUM *e = BN_new();
    BN_CTX *ctx = BN_CTX_new();

    // Convert the hexadecimal strings to BIGNUM
    BN_hex2bn(&Message, "506c656173652070617920243130303020776974682074686973206c696e6b");
    BN_hex2bn(&S, "BC21FB5AE742C952C7AB1B48A932257CAF301EC5F02F876124C41E219FAD5209");
    BN_hex2bn(&Modified_S, "BC21FB5AE742C952C7AB1B48A932257CAF301EC5F02F876124C41E219FAD5219");
    BN_hex2bn(&e, "0D88C3");
    BN_hex2bn(&n, "E103ABD94892E3E74AFD724BF28E78366D9676BCCC70118BD0AA1968DBB143D1");

    // Verify the original signature
    printf("Verifying original signature:\n");
    verify_signature(Message, S, e, n, ctx);

    // Verify the modified signature
    printf("Verifying modified signature:\n");
    verify_signature(Message, Modified_S, e, n, ctx);

    // Free memory
    BN_free(S);
    BN_free(Modified_S);
    BN_free(n);
    BN_free(e);
    BN_free(Message);
    BN_CTX_free(ctx);

    return 0;
}

