#include <stdio.h>
#include <openssl/bn.h>

// Function to calculate the digital signature: DS = M^d mod n
BIGNUM* calculate_signature(BIGNUM *message, BIGNUM *d, BIGNUM *n, BN_CTX *ctx) {
    BIGNUM *signature = BN_new();
    BN_mod_exp(signature, message, d, n, ctx);
    return signature;
}

int main() {
    BIGNUM *M = BN_new();             
    BIGNUM *Modified = BN_new();    
    BIGNUM *n = BN_new();            
    BIGNUM *d = BN_new();            
    BN_CTX *ctx = BN_CTX_new();

    BN_hex2bn(&M, "492070617920796f752024353632"); // "I pay you $562"
    BN_hex2bn(&Modified, "492070617920796f752024363632"); // "I pay you $662"
    BN_hex2bn(&d, "3587A24598E5F2A21DB007D89D18CC50ABA5075BA19A33890FE7C28A9B496AEB"); // Private exponent
    BN_hex2bn(&n, "E103ABD94892E3E74AFD724BF28E78366D9676BCCC70118BD0AA1968DBB143D1"); // Modulus

    // Calculate signatures for both the original and modified messages using the function
    BIGNUM *DS = calculate_signature(M, d, n, ctx);
    BIGNUM *DS_modified = calculate_signature(Modified, d, n, ctx);

    // Output the original and modified messages
    char *M_str = BN_bn2hex(M);
    printf("Original Message: %s\n", M_str);

    char *Modified_str = BN_bn2hex(Modified);
    printf("Modified Message: %s\n", Modified_str);

    // Output the calculated signatures
    char *DS_str = BN_bn2hex(DS);
    printf("Signature of Original Message: %s\n", DS_str);

    char *DS_modified_str = BN_bn2hex(DS_modified);
    printf("Signature of Modified Message: %s\n", DS_modified_str);

    // Free memory
    BN_free(M);
    BN_free(Modified);
    BN_free(n);
    BN_free(d);
    BN_free(DS);
    BN_free(DS_modified);
    BN_CTX_free(ctx);
    OPENSSL_free(M_str);
    OPENSSL_free(Modified_str);
    OPENSSL_free(DS_str);
    OPENSSL_free(DS_modified_str);

    return 0;
}

