#!/usr/bin/env python3

import socket
import ssl
import sys
import pprint

hostname = sys.argv[1]
port = 443
cadir = './client-certs'
#cadir= './etc/ssl/certs'

# Set up the TLS context
context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
#context.load_verify_locations(cafile="./client-certs/ca.crt")
context.load_verify_locations(capath=cadir)
context.verify_mode = ssl.CERT_REQUIRED
context.check_hostname = False

# Create a TCP connection
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.connect((hostname, port))
print("TCP connection established.")

# Add TLS layer
ssock = context.wrap_socket(sock, server_hostname=hostname, do_handshake_on_connect=False)
ssock.do_handshake()  # Perform the handshake
print("TLS handshake complete.")
print("Cipher used:", ssock.cipher())
print("Server certificate:")
pprint.pprint(ssock.getpeercert())

# Send HTTP GET request to the server
request = f"GET / HTTP/1.1\r\nHost: {hostname}\r\nConnection: close\r\n\r\n"
ssock.sendall(request.encode('utf-8'))
print("HTTP request sent.")

# Receive the response from the server
response = ssock.recv(2048)
print("Response:")
while response:
    print(response.decode('utf-8', errors='ignore'))
    response = ssock.recv(2048)

# Close the TLS connection
ssock.shutdown(socket.SHUT_RDWR)
ssock.close()
print("Connection closed.")

