#!/usr/bin/env python3

import socket
import ssl

html = """
HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n
<!DOCTYPE html>
<html>
<body>
<h1>Hello, TLS World!</h1>
</body>
</html>
"""

# Paths to server certificate and private key
SERVER_CERT = "./server-certs/server.crt"
SERVER_PRIVATE = "./server-certs/server.key"

# Set up TLS context
context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
context.load_cert_chain(SERVER_CERT, SERVER_PRIVATE)

# Create and bind the socket
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
sock.bind(("0.0.0.0", 443))  # Listen on all interfaces, port 443
sock.listen(5)
print("Server listening on port 443...")

while True:
    newsock, fromaddr = sock.accept()
    try:
        ssock = context.wrap_socket(newsock, server_side=True)
        print("TLS connection established")
        
        # Handle client request
        data = ssock.recv(1024)  # Read request from client
        print("Request:", data.decode('utf-8', errors='ignore'))
        ssock.sendall(html.encode('utf-8'))  # Send response to client
        
        # Close TLS connection
        ssock.shutdown(socket.SHUT_RDWR)
        ssock.close()
    except Exception as e:
        print("TLS connection failed:", e)
        continue

