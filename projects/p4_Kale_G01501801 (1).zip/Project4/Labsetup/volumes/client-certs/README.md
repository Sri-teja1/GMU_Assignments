
This folder stores the certificates needed by the client program.
It is used by the client container.
